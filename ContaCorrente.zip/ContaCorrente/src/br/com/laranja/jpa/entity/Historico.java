package br.com.laranja.jpa.entity;

import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_HISTORICO")
@SequenceGenerator(sequenceName = "SQ_TB_HISTORICO", name = "historico", allocationSize = 1)
public class Historico{
    @Id
    @Column(name = "cd_historico", length = 4)
    @GeneratedValue(generator = "historico", strategy = GenerationType.SEQUENCE)
    private int codigo;
    
    @Column(name = "cd_codigo", nullable = false, length = 3)
    private Conta conta;

    @Column(name = "ds_tipo", nullable = false, length = 30)
    private String tipo;

    @Column(name = "dt_registro" , nullable = false)
    @Temporal(TemporalType.DATE)
    private Calendar registro;

    public Historico() {
        super();
    }
    

    public Historico(int codigo, Conta conta, String tipo, Calendar registro) {
        this.codigo = codigo;
        this.conta = conta;
        this.tipo = tipo;
        this.registro = registro;
    }


    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Conta getConta() {
        return conta;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Calendar getRegistro() {
        return registro;
    }

    public void setRegistro(Calendar registro) {
        this.registro = registro;
    }




}