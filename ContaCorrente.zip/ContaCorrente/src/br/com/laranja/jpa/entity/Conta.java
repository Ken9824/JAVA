package br.com.laranja.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TB_CONTA_CORRENTE")
@SequenceGenerator(sequenceName = "SQ_TB_CONTA_CORRENTE", name = "conta", allocationSize = 1)
public class Conta {
    @Id
    @Column(name = "cd_conta", length = 3)
    @GeneratedValue(generator = "conta", strategy = GenerationType.SEQUENCE)
    private int codigo;
    
    @Column(name = "cd_agencia", nullable = false, length = 4)
    private Agencia agencia;
    
    @Column(name = "vl_saldo", nullable = false)
    private double saldo;
    
    @Column(name = "vl_credito", nullable = false)
    private double credito;
    
    
    public Conta(){
        super();
    }
    
    public Conta(int codigo, double saldo, double credito) {
        this.codigo = codigo;
        this.saldo = saldo;
        this.credito = credito;
    }
    


    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Agencia getAgencia() {
        return agencia;
    }

    public void setAgencia(Agencia agencia) {
        this.agencia = agencia;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getCredito() {
        return credito;
    }

    public void setCredito(double credito) {
        this.credito = credito;
    }

}