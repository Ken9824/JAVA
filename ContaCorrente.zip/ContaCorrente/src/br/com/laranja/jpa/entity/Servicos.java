package br.com.laranja.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_SERVICOS")
public class Servicos{

	@Id
	@Column(name = "cd_servico", length = 2)
	private int codigo;
	
	@Column(name = "ds_servico", nullable = false, length = 50)
	private String descricao;
	
	@Column(name = "vl_servico", nullable = false /*length = 7 perguntar pro Thiago*/)
	private double valor;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public Servicos(int codigo, String descricao, double valor) {
		super();
		this.codigo = codigo;
		this.descricao = descricao;
		this.valor = valor;
	}

	public Servicos() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
