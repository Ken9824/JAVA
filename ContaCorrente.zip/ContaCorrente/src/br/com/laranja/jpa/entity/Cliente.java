package br.com.laranja.jpa.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="TB_CLIENTE")
@SequenceGenerator(name="SQ_TB_CLIENTE", sequenceName = "cliente", allocationSize = 1)
public class Cliente {

	@Id
	@Column(name="cd_cliente", length = 3)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="cliente")
	private int codigo;
	
	//@Column(name="cd_conta")
	//private Conta conta;
	
	@Column(name="nm_cliente", nullable = false, length = 50)
	private String nome;
	
	@Column(name = "dt_nascimento", nullable = false)
	@Temporal(TemporalType.DATE)
	private Calendar nascimento;
	
	@Column(name = "nr_rg" , nullable = false, length = 9)
	private int rg;
	
	@Column(name = "sn_cliente", nullable = false, length = 6)
	private String senha;
	
	@Column(name = "nr_telefone", nullable = false, length = 11)
	private int telefone;
	
	@Column(name = "ds_email", nullable = false, length = 100)
	private String email;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Calendar getNascimento() {
		return nascimento;
	}

	public void setNascimento(Calendar nascimento) {
		this.nascimento = nascimento;
	}

	public int getRg() {
		return rg;
	}

	public void setRg(int rg) {
		this.rg = rg;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Cliente(String nome, Calendar nascimento, int rg, String senha, int telefone, String email) {
		super();
		this.nome = nome;
		this.nascimento = nascimento;
		this.rg = rg;
		this.senha = senha;
		this.telefone = telefone;
		this.email = email;
	}

	public Cliente() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
