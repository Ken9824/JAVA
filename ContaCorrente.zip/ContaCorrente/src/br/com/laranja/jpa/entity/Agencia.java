package br.com.laranja.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_AGENCIA")
public class Agencia{
    @Id
    @Column(name = "cd_agencia", length = 4)
    private int codigo;

    @Column(name = "ds_endereco", length = 100, nullable = false)
    private String endereco;

    public Agencia() {
        super();
    }

    public Agencia(int codigo, String endereco) {
        this.codigo = codigo;
        this.endereco = endereco;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    
}