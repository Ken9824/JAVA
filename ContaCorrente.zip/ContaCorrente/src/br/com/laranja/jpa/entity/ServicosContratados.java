package br.com.laranja.jpa.entity;


import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_SERVICOS_CONTRATADOS")
public class ServicosContratados{
    @Id
    @Column(name = "cd_codigo", length = 2)
    private Conta conta;
    
    @Column(name = "cd_servico", nullable = false, length = 2)
    private Servicos servico;
    
    @Column(name = "dt_contratacao", nullable = false)
    @Temporal(TemporalType.DATE)
    private Calendar contratacao;
    
    @Column(name = "st_servico", nullable = false, length = 10)
    private String status;
    
    @Column(name = "dt_termino")
    private Calendar termino;

	public Conta getConta() {
		return conta;
	}

	public void setConta(Conta conta) {
		this.conta = conta;
	}

	public Servicos getServico() {
		return servico;
	}

	public void setServico(Servicos servico) {
		this.servico = servico;
	}

	public Calendar getContratacao() {
		return contratacao;
	}

	public void setContratacao(Calendar contratacao) {
		this.contratacao = contratacao;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Calendar getTermino() {
		return termino;
	}

	public void setTermino(Calendar termino) {
		this.termino = termino;
	}

	public ServicosContratados(Calendar contratacao, String status, Calendar termino) {
		super();
		this.contratacao = contratacao;
		this.status = status;
		this.termino = termino;
	}

	public ServicosContratados() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}