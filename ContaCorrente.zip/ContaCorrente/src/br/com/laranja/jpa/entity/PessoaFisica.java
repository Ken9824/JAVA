package br.com.laranja.jpa.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TB_FISICA")
@SequenceGenerator(name = "SQ_TB_FISICA", sequenceName = "fisica", allocationSize = 1)
public class PessoaFisica extends Cliente{

	@Column(name="cd_fisica", nullable = false, length = 3)
	private int codigo;
	
	@Column(name="nr_cpf", nullable = false, length = 11)
	private int cpf;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}

	public PessoaFisica(String nome, Calendar nascimento, int rg, String senha, int telefone, String email, int cpf) {
		super(nome, nascimento, rg, senha, telefone, email);
		this.cpf = cpf;
	}

	public PessoaFisica() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PessoaFisica(String nome, Calendar nascimento, int rg, String senha, int telefone, String email) {
		super(nome, nascimento, rg, senha, telefone, email);
		// TODO Auto-generated constructor stub
	}
	
	
}
