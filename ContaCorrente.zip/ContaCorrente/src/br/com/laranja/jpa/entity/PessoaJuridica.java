package br.com.laranja.jpa.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TB_JURIDICA")
@SequenceGenerator(name = "SQ_TB_JURIDICA", sequenceName = "juridica", allocationSize = 1)
public class PessoaJuridica extends Cliente{
	
	@Column(name = "cd_juridica", nullable = false, length = 3)
	private int codigo;
	
	@Column(name = "nr_cnpj", nullable = false, length = 14)
	private int cnpj;
	
	@Column(name = "ds_razao_social", nullable = false, length = 50)
	private String razaoSocial;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCnpj() {
		return cnpj;
	}

	public void setCnpj(int cnpj) {
		this.cnpj = cnpj;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public PessoaJuridica(String nome, Calendar nascimento, int rg, String senha, int telefone, String email, int cnpj,
			String razaoSocial) {
		super(nome, nascimento, rg, senha, telefone, email);
		this.cnpj = cnpj;
		this.razaoSocial = razaoSocial;
	}

	public PessoaJuridica() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PessoaJuridica(String nome, Calendar nascimento, int rg, String senha, int telefone, String email) {
		super(nome, nascimento, rg, senha, telefone, email);
		// TODO Auto-generated constructor stub
	}
	
	
}
