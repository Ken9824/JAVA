package br.com.laranja.jpa.dao;

import br.com.laranja.jpa.exception.CommitException;
import br.com.laranja.jpa.exception.KeyNotFoundException;

public interface GenericDAO<K, T> {
	
	void cadastrar(T entity); 
	
	void atualizar(T entity);
	
	T ler (K key);
	
	void deletar (K key) throws KeyNotFoundException;
	
	void commit() throws CommitException;
}
