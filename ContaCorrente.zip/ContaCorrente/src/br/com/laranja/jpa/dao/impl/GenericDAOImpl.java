package br.com.laranja.jpa.dao.impl;

import javax.persistence.EntityManager;

import br.com.laranja.jpa.dao.GenericDAO;
import br.com.laranja.jpa.exception.CommitException;
import br.com.laranja.jpa.exception.KeyNotFoundException;

public class GenericDAOImpl<T, K> implements GenericDAO<K, T> {

	private EntityManager em;
	
	private Class<T> clazz;
	
	@Override
	public void cadastrar(T entity) {
		em.persist(entity);
		
	}

	@Override
	public void atualizar(T entity) {
		em.merge(entity);
		
	}

	@Override
	public T ler(K key) {
		return em.find(clazz, key);
	}

	@Override
	public void deletar(K key) throws KeyNotFoundException{
		T entity = ler(key);
		if(entity == null) {
			throw new KeyNotFoundException();
		}
		em.remove(entity);
		
	}

	@Override
	public void commit() throws CommitException{
		try {
			em.getTransaction().begin();
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new CommitException(e.getMessage());
		}
		
	}
	
}
